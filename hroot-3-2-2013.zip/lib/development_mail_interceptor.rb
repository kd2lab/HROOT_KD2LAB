class DevelopmentMailInterceptor
  def self.delivering_email(message)
    unless Rails.env.production?
      message.subject = "#{message.to} #{message.subject}"
      message.to = "<enter you test email adress here>"
    end
  end
end