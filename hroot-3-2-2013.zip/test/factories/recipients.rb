# Read about factories at http://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :recipient do
    message_id 1
    user_id 1
  end
end
