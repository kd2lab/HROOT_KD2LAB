require 'test_helper'

class SessionParticipationTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
