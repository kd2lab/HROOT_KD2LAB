require 'test_helper'

class ExperimentsHelperTest < ActionView::TestCase
end
