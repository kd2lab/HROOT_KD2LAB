require 'test_helper'

class OptionsHelperTest < ActionView::TestCase
end
