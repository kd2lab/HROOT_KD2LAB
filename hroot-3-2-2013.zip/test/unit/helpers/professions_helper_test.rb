require 'test_helper'

class ProfessionsHelperTest < ActionView::TestCase
end
