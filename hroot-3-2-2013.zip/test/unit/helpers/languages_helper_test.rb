require 'test_helper'

class LanguagesHelperTest < ActionView::TestCase
end
