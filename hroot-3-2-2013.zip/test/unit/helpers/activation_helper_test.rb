require 'test_helper'

class ActivationHelperTest < ActionView::TestCase
end
