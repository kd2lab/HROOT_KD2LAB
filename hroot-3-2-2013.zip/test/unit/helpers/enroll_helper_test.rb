require 'test_helper'

class EnrollHelperTest < ActionView::TestCase
end
