require 'test_helper'

class PasswordResetsControllerHelperTest < ActionView::TestCase
end
