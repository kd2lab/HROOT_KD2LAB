require 'test_helper'

class UsersControllerHelperTest < ActionView::TestCase
end
