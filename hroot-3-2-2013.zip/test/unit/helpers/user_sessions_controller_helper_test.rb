require 'test_helper'

class UserSessionsControllerHelperTest < ActionView::TestCase
end
