require 'test_helper'

class DegreeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
