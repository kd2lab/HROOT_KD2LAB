require 'test_helper'

class ProfessionsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
