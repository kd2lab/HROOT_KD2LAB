# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Hroot::Application.config.secret_token = '00416738dde2dcee5b91ab1258847149cd5b75652cd0f95509813fb3ee6d429d4fbae416223dc362192ce3e7537cf9118ba0097f685d22045677335b763e4f6d'
