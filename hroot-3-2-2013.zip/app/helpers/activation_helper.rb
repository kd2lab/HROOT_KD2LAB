module ActivationHelper
end
